function main($scope, $http, $window, $attrs) {
  // used for extra initialization of the Main controller
}

var app = Rapidoid.createApp(main);
