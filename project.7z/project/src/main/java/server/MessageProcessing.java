package server;

import java.time.Instant;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.rapidoid.http.Req;

import server.model.Message;

public class MessageProcessing {

	static byte[] respBody = new byte[0];

	static Map<Integer, List<Message>> map = new HashMap<>();

	static DateTimeFormatter f = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSZ");

	public static Object processMessage(Req req) {

		String id = req.posted("id");
		long ts = Instant.from(f.parse((String) req.posted("timestamp"))).getEpochSecond();
		int st = (int) req.posted("sensorType");
		long val = (int) req.posted("value");

		//System.out.println(id + ";" + ts + ";" + st + ";" + val + "\n");

		Message msg = new Message(id, ts, st, val);

		List<Message> msgList = map.get(st);
		if (msgList == null) {
			msgList = new ArrayList<>();
			map.put(st, msgList);
		}

		msgList.add(msg);

		return respBody;
	}
}
