package server.model;

public class Message {

	public String id;
	public long timestamp;
	public int sensorType;
	public long value;

	public Message(String id, long timestamp, int sensorType, long value) {
		this.id = id;
		this.timestamp = timestamp;
		this.sensorType = sensorType;
		this.value = value;
	}

}
