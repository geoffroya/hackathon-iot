package server.http;

import org.rapidoid.http.impl.HttpParser;

public class CustomHttpParser extends HttpParser {

}
