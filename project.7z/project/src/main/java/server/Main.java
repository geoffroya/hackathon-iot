package server;

import java.util.HashSet;
import java.util.Set;

import org.rapidoid.config.Conf;
import org.rapidoid.setup.On;

// TODO Parsing de date a optimizer
public class Main {

	public static Set<Integer> sensorType = new HashSet<>();

	public static void main(String[] args) {
		// Initialize the configuration:
		Conf.args(args);

		On.post("/messages").plain(req -> MessageProcessing.processMessage(req));
		On.get("/messages/synthesis").json(req -> SynthesisProcessing.processSynthesis(req));
	}
}
